-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: courses_teacher
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `fio` varchar(250) DEFAULT NULL,
  `2020-12-20` int DEFAULT NULL,
  `2020-12-22` int DEFAULT NULL,
  `2020-12-25` int NOT NULL,
  `2020-12-28` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'Java ','Иванов Иван Иванович',4,4,5,4),(2,'Java ','Грехов Сергей Михайлович',4,5,5,3),(3,'Java ','Востряков Кирилл Эдуардович',5,4,3,5),(4,'Java ','Прытков Дмитрий Олегович',4,5,5,4),(5,'Python курс','Иванов Иван Иванович',3,4,4,4),(6,'Python курс','Грехов Сергей Михайлович',4,5,4,4),(7,'Python курс','Востряков Кирилл Эдуардович',3,3,4,4),(8,'Python курс','Прытков Дмитрий Олегович',4,5,5,5),(9,'Java','Молокин Александр Алексеевич',5,4,3,4),(10,'Java','Алипов Артем Антонович',4,5,4,3),(11,'Java','Серебряков Алексей Александрович',5,5,4,5),(12,'Java','Стожков Данила Алексеевич',4,5,4,5),(13,'Java','Чанов Алексей Михайлович',5,4,5,4),(14,'Python курс','Молокин Александр Алексеевич',3,4,5,5),(15,'Python курс','Алипов Артем Антонович',4,4,3,4),(16,'Python курс','Серебряков Алексей Александрович',5,4,5,4),(17,'Python курс','Стожков Данила Алексеевич',5,5,5,4),(18,'Python курс','Чанов Алексей Михайлович',4,5,4,5),(19,'C++ курс','Иванов Иван Иванович',4,5,5,4),(20,'C++ курс','Грехов Сергей Михайлович',3,4,5,3),(21,'C++ курс','Востряков Кирилл Эдуардович',4,3,4,5),(22,'C++ курс','Прытков Дмитрий Олегович',4,4,4,3),(23,'C++ курс','Молокин Александр Алексеевич',5,3,4,5),(24,'C++ курс','Алипов Артем Антонович',4,3,4,4),(25,'C++ курс','Серебряков Алексей Александрович',5,4,5,4),(26,'C++ курс','Стожков Данила Алексеевич',4,5,5,5),(27,'C++ курс','Веряскин Александр Кириллович',3,4,5,3);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-27 22:18:03
