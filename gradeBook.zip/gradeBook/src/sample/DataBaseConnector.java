package sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnector {
    public final String URL="jdbc:mysql://localhost:3306/courses_teacher?serverTimezone=UTC";
    public final String DRIVER="com.mysql.cj.jdbc.Driver";
    public final String LOGIN="root";
    public final String PASSWORD="2216";

    public Connection getConnection() throws ClassNotFoundException, SQLException {
        Connection connection=null;
        Class.forName(DRIVER);
        connection= DriverManager.getConnection(URL,LOGIN,PASSWORD);
        return connection;
    }
    public void closeConnection(Connection connection){
        if (connection==null)return;
        try {
            connection.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
