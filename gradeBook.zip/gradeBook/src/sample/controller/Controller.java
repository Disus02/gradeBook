package sample.controller;

import com.opencsv.CSVWriter;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.Window;
import sample.DataBaseConnector;
import sample.Main;
import sample.model.Course;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Controller {
    private Connection connection;
    public Controller() throws SQLException, ClassNotFoundException {connection=new DataBaseConnector().getConnection();
    }
    @FXML
    private TabPane tabCourse;
    @FXML
    private Label status;
    @FXML
    private Label labelC;
    @FXML
    private Label labelPython;
    @FXML
    private TableView<Course> tableJava;
    @FXML
    private TableView<Course> tablePython;
    @FXML
    private TableView<Course> tableC;
    @FXML
    private TableColumn<Course,String> columnFioJ;
    @FXML
    private TableColumn<Course,String> columnData1J;
    @FXML
    private TableColumn<Course,String> columnData2J;
    @FXML
    private TableColumn<Course,String> columnData3J;
    @FXML
    private TableColumn<Course,String> columnData4J;
    @FXML
    private TableColumn<Course,String> columnFioP;
    @FXML
    private TableColumn<Course,String> columnData1P;
    @FXML
    private TableColumn<Course,String> columnData2P;
    @FXML
    private TableColumn<Course,String> columnData3P;
    @FXML
    private TableColumn<Course,String> columnData4P;
    @FXML
    private TableColumn<Course,String> columnFioC;
    @FXML
    private TableColumn<Course,String> columnData1C;
    @FXML
    private TableColumn<Course,String> columnData2C;
    @FXML
    private TableColumn<Course,String> columnData3C;
    @FXML
    private TableColumn<Course,String> columnData4C;


//создание массивов для дальнейшей работы с информацией о курсах
    ObservableList<Course> javaC= FXCollections.observableArrayList();
    ObservableList<Course> pythonC=FXCollections.observableArrayList();
    ObservableList<Course> courseC=FXCollections.observableArrayList();

    //метод вывода данных в таблицы с курсами
    public void initialize(){

        //разрешение изменения данных внутри таблицы
        tableJava.setEditable(true);
        tablePython.setEditable(true);
        tableC.setEditable(true);

        // выборка данных для курса в таблицу из базы данных
        try {
            String courseName="Java";
            String sql="SELECT * FROM course WHERE name=?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1,courseName);
            ResultSet result=statement.executeQuery();
            while (result.next()){
                javaC.add(new Course(result.getInt(1),result.getString(2),
                        result.getString(3),result.getString(4),
                        result.getString(5),result.getString(6),result.getString(7)));
            }
            columnFioJ.setCellValueFactory(new PropertyValueFactory<>("fio"));
            columnData1J.setCellValueFactory(new PropertyValueFactory<>("data1"));
            columnData1J.setCellFactory(TextFieldTableCell.<Course>forTableColumn());
            columnData1J.setMinWidth(50);
            columnData1J.setOnEditCommit((TableColumn.CellEditEvent<Course, String> event) -> {
                        TablePosition<Course, String> pos = event.getTablePosition();
                        String newData = event.getNewValue();
                        int row = pos.getRow();
                for (Course course:javaC) {
                    course = event.getTableView().getItems().get(row);
                    course.setData1(newData);
                }
                    });
            columnData2J.setCellValueFactory(new PropertyValueFactory<>("data2"));
            columnData2J.setCellFactory(TextFieldTableCell.<Course>forTableColumn());
            columnData2J.setMinWidth(50);
            columnData2J.setOnEditCommit((TableColumn.CellEditEvent<Course, String> event) -> {
                TablePosition<Course, String> pos = event.getTablePosition();
                String newData = event.getNewValue();
                int row = pos.getRow();
                for (Course course:javaC) {
                    course = event.getTableView().getItems().get(row);
                    course.setData2(newData);
                }
            });
            columnData3J.setCellValueFactory(new PropertyValueFactory<>("data3"));
            columnData3J.setCellFactory(TextFieldTableCell.<Course>forTableColumn());
            columnData3J.setMinWidth(50);
            columnData3J.setOnEditCommit((TableColumn.CellEditEvent<Course, String> event) -> {
                TablePosition<Course, String> pos = event.getTablePosition();
                String newData = event.getNewValue();
                int row = pos.getRow();
                for (Course course:javaC) {
                    course = event.getTableView().getItems().get(row);
                    course.setData3(newData);
                }
            });
            columnData4J.setCellValueFactory(new PropertyValueFactory<>("data4"));
            columnData4J.setCellFactory(TextFieldTableCell.<Course>forTableColumn());
            columnData4J.setMinWidth(50);
            columnData4J.setOnEditCommit((TableColumn.CellEditEvent<Course, String> event) -> {
                TablePosition<Course, String> pos = event.getTablePosition();
                String newData = event.getNewValue();
                int row = pos.getRow();
                for (Course course:javaC) {
                    course = event.getTableView().getItems().get(row);
                    course.setData4(newData);
                }
            });
            tableJava.setItems(javaC);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


// выборка данных для курса в таблицу из базы данных
        try {
            String courseName="Python курс";
            String sqlSelect="SELECT * FROM course WHERE name=?";
            PreparedStatement statement = connection.prepareStatement(sqlSelect);
            statement.setString(1,courseName);
            ResultSet result=statement.executeQuery();
            while (result.next()){
                pythonC.add(new Course(result.getInt(1),result.getString(2),
                        result.getString(3),result.getString(4),
                        result.getString(5),result.getString(6),result.getString(7)));
            }
            columnFioP.setCellValueFactory(new PropertyValueFactory<>("fio"));
            columnData1P.setCellValueFactory(new PropertyValueFactory<>("data1"));
            columnData1P.setCellFactory(TextFieldTableCell.<Course>forTableColumn());
            columnData1P.setMinWidth(50);
            columnData1P.setOnEditCommit((TableColumn.CellEditEvent<Course, String> event) -> {
                TablePosition<Course, String> pos = event.getTablePosition();
                String newData = event.getNewValue();
                int row = pos.getRow();
                for (Course course:pythonC) {
                    course = event.getTableView().getItems().get(row);
                    course.setData1(newData);
                }
            });
            columnData2P.setCellValueFactory(new PropertyValueFactory<>("data2"));
            columnData2P.setCellFactory(TextFieldTableCell.<Course>forTableColumn());
            columnData2P.setMinWidth(50);
            columnData2P.setOnEditCommit((TableColumn.CellEditEvent<Course, String> event) -> {
                TablePosition<Course, String> pos = event.getTablePosition();
                String newData = event.getNewValue();
                int row = pos.getRow();
                for (Course course:pythonC) {
                    course = event.getTableView().getItems().get(row);
                    course.setData2(newData);
                }
            });
            columnData3P.setCellValueFactory(new PropertyValueFactory<>("data3"));
            columnData3P.setCellFactory(TextFieldTableCell.<Course>forTableColumn());
            columnData3P.setMinWidth(50);
            columnData3P.setOnEditCommit((TableColumn.CellEditEvent<Course, String> event) -> {
                TablePosition<Course, String> pos = event.getTablePosition();
                String newData = event.getNewValue();
                int row = pos.getRow();
                for (Course course:pythonC) {
                    course = event.getTableView().getItems().get(row);
                    course.setData3(newData);
                }
            });
            columnData4P.setCellValueFactory(new PropertyValueFactory<>("data4"));
            columnData4P.setCellFactory(TextFieldTableCell.<Course>forTableColumn());
            columnData4P.setMinWidth(50);
            columnData4P.setOnEditCommit((TableColumn.CellEditEvent<Course, String> event) -> {
                TablePosition<Course, String> pos = event.getTablePosition();
                String newData = event.getNewValue();
                int row = pos.getRow();
                for (Course course:pythonC) {
                    course = event.getTableView().getItems().get(row);
                    course.setData4(newData);
                }
            });
            tablePython.setItems(pythonC);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }



// выборка данных для курса в таблицу из базы данных
        try {
            String courseName="C++ курс";
            String sqlSelect="SELECT * FROM course WHERE name=?";
            PreparedStatement statement = connection.prepareStatement(sqlSelect);
            statement.setString(1,courseName);
            ResultSet result=statement.executeQuery();
            while (result.next()){
                courseC.add(new Course(result.getInt(1),result.getString(2),
                        result.getString(3),result.getString(4),
                        result.getString(5),result.getString(6),result.getString(7)));
            }
            columnFioC.setCellValueFactory(new PropertyValueFactory<>("fio"));
            columnData1C.setCellValueFactory(new PropertyValueFactory<>("data1"));
            columnData1C.setCellFactory(TextFieldTableCell.<Course>forTableColumn());
            columnData1C.setMinWidth(50);
            columnData1C.setOnEditCommit((TableColumn.CellEditEvent<Course, String> event) -> {
                TablePosition<Course, String> pos = event.getTablePosition();
                String newData = event.getNewValue();
                int row = pos.getRow();
                for (Course course:courseC) {
                    course = event.getTableView().getItems().get(row);
                    course.setData1(newData);
                }
            });
            columnData2C.setCellValueFactory(new PropertyValueFactory<>("data2"));
            columnData2C.setCellFactory(TextFieldTableCell.<Course>forTableColumn());
            columnData2C.setMinWidth(50);
            columnData2C.setOnEditCommit((TableColumn.CellEditEvent<Course, String> event) -> {
                TablePosition<Course, String> pos = event.getTablePosition();
                String newData = event.getNewValue();
                int row = pos.getRow();
                for (Course course:courseC) {
                    course = event.getTableView().getItems().get(row);
                    course.setData2(newData);
                }
            });
            columnData3C.setCellValueFactory(new PropertyValueFactory<>("data3"));
            columnData3C.setCellFactory(TextFieldTableCell.<Course>forTableColumn());
            columnData3C.setMinWidth(50);
            columnData3C.setOnEditCommit((TableColumn.CellEditEvent<Course, String> event) -> {
                TablePosition<Course, String> pos = event.getTablePosition();
                String newData = event.getNewValue();
                int row = pos.getRow();
                for (Course course:courseC) {
                    course = event.getTableView().getItems().get(row);
                    course.setData3(newData);
                }
            });
            columnData4C.setCellValueFactory(new PropertyValueFactory<>("data4"));
            columnData4C.setCellFactory(TextFieldTableCell.<Course>forTableColumn());
            columnData4C.setMinWidth(50);
            columnData4C.setOnEditCommit((TableColumn.CellEditEvent<Course, String> event) -> {
                TablePosition<Course, String> pos = event.getTablePosition();
                String newData = event.getNewValue();
                int row = pos.getRow();
                for (Course course:courseC) {
                    course = event.getTableView().getItems().get(row);
                    course.setData4(newData);
                }
            });
            tableC.setItems(courseC);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    //сохранение измененных данных для курса в базу данных
    @FXML
    public void pressSaveJ(ActionEvent event) throws SQLException {
        String sqlUpdate="UPDATE course SET `2020-12-20`=?, `2020-12-22`=?, `2020-12-25`=?,`2020-12-28`=? WHERE id=?";
        PreparedStatement statement=connection.prepareStatement(sqlUpdate);
        for (Course course:javaC) {
            statement.setInt(1,Integer.parseInt(course.getData1()));
            statement.setInt(2,Integer.parseInt(course.getData2()));
            statement.setInt(3,Integer.parseInt(course.getData3()));
            statement.setInt(4,Integer.parseInt(course.getData4()));
            statement.setInt(5,course.getId());
            int result=statement.executeUpdate();
            if (result==1){
                status.setText("Данные сохранены");
            }else status.setText("Ошибка");
        }

    }

    //сохранение измененных данных для курса в базу данных
    @FXML
    public void pressSaveP(ActionEvent event) throws SQLException {
        String sqlUpdate="UPDATE course SET `2020-12-20`=?, `2020-12-22`=?, `2020-12-25`=?,`2020-12-28`=? WHERE id=?";
        PreparedStatement statement=connection.prepareStatement(sqlUpdate);
        for (Course course:pythonC) {
            statement.setInt(1,Integer.parseInt(course.getData1()));
            statement.setInt(2,Integer.parseInt(course.getData2()));
            statement.setInt(3,Integer.parseInt(course.getData3()));
            statement.setInt(4,Integer.parseInt(course.getData4()));
            statement.setInt(5,course.getId());
            int result=statement.executeUpdate();
            if (result==1){
                labelPython.setText("Данные сохранены");
            }else labelPython.setText("Ошибка");
        }

    }

    //сохранение измененных данных для курса в базу данных
    @FXML
    public void pressSaveC(ActionEvent event) throws SQLException {
        String sqlUpdate="UPDATE course SET `2020-12-20`=?, `2020-12-22`=?, `2020-12-25`=?,`2020-12-28`=? WHERE id=?";
        PreparedStatement statement=connection.prepareStatement(sqlUpdate);
        for (Course course:courseC) {
            statement.setInt(1,Integer.parseInt(course.getData1()));
            statement.setInt(2,Integer.parseInt(course.getData2()));
            statement.setInt(3,Integer.parseInt(course.getData3()));
            statement.setInt(4,Integer.parseInt(course.getData4()));
            statement.setInt(5,course.getId());
            int result=statement.executeUpdate();
            if (result==1){
                labelC.setText("Данные сохранены");
            }else labelC.setText("Ошибка");
        }
    }

    //экспорт данных в формате .csv
    @FXML
    public void pressExport(ActionEvent event) throws Exception {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Document");
        FileChooser.ExtensionFilter extFilter =
                new FileChooser.ExtensionFilter("CSV files (*.csv)", "*.csv");
        fileChooser.getExtensionFilters().add(extFilter);
        File file = fileChooser.showSaveDialog(new Stage());
        PrintWriter pW = new PrintWriter(file, "windows-1251");
        String fio="ФИО";
        String data1="2020-12-20";
        String data2="2020-12-22";
        String data3="2020-12-25";
        String data4="2020-12-28";
        pW.write(String.format("%s; %s; %s; %s; %s \n",fio,data1,data2,data3,data4));
        SingleSelectionModel<Tab> selectionModel = tabCourse.getSelectionModel();
        if (selectionModel.getSelectedIndex()==0){
            for (Course course:javaC) {
                pW.write(course.toString());
            }
        }
        if (selectionModel.getSelectedIndex()==1){
            for (Course course:pythonC) {
                pW.write(course.toString());
            }
        }
        if (selectionModel.getSelectedIndex()==2){
            for (Course course:courseC) {
                pW.write(course.toString());
            }
        }
        pW.close();
    }


    //выход из приложения и проверка на сохраняемость данных
    @FXML
    public void pressExit(ActionEvent event) throws SQLException, IOException {
        ObservableList<Course> javaTest=FXCollections.observableArrayList();
        String courseNames="Java";
        String sqlSelect="SELECT * FROM course WHERE name=?";
        PreparedStatement statement=connection.prepareStatement(sqlSelect);
        statement.setString(1,courseNames);
        ResultSet result=statement.executeQuery();
        while (result.next()){
            javaTest.add(new Course(result.getInt(1),result.getString(2),
                    result.getString(3),result.getString(4),
                    result.getString(5),result.getString(6),result.getString(7)));
        }
        ObservableList<Course> pythonTest=FXCollections.observableArrayList();
        String courseName="Python курс";
        String sqlSelect1="SELECT * FROM course WHERE name=?";
        PreparedStatement statement1=connection.prepareStatement(sqlSelect1);
        statement1.setString(1,courseName);
        ResultSet result1=statement1.executeQuery();
        while (result1.next()){
            pythonTest.add(new Course(result1.getInt(1),result1.getString(2),
                    result1.getString(3),result1.getString(4),
                    result1.getString(5),result1.getString(6),result1.getString(7)));
        }
        ObservableList<Course> cTest=FXCollections.observableArrayList();
        String courseName1="C++ курс";
        String sqlSelect2="SELECT * FROM course WHERE name=?";
        PreparedStatement statement2=connection.prepareStatement(sqlSelect2);
        statement2.setString(1,courseName1);
        ResultSet result2=statement2.executeQuery();
        while (result2.next()){
            cTest.add(new Course(result2.getInt(1),result2.getString(2),
                    result2.getString(3),result2.getString(4),
                    result2.getString(5),result2.getString(6),result2.getString(7)));
        }
        if (javaTest.equals(javaC)&&pythonC.equals(pythonTest)&&cTest.equals(courseC)){
            System.exit(0);
        }else {
            Parent root = FXMLLoader.load(getClass().getResource("/sample/view/confirmClose.fxml"));
            Stage stage=new Stage();
            stage.setScene(new Scene(root));
            MenuItem menuItem = (MenuItem)event.getTarget();
            ContextMenu cMenu = menuItem.getParentPopup();
            Scene scene = cMenu.getScene();
            Window window = scene.getWindow();
            stage.initOwner( window );
            stage.show();
        }
    }


}
