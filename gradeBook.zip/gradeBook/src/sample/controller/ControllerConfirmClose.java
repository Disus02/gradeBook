package sample.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class ControllerConfirmClose {
    @FXML
    private Button buttonClose;
    @FXML
    public void pressExit(ActionEvent event){
        System.exit(0);
    }

    @FXML
    public void pressCancel(ActionEvent event){
        buttonClose.getScene().getWindow().hide();
    }

}
